#include "UndirectedGraph.hpp"

int main()
{
	UndirectedGraph g(5,'l');
	g.add(1,2,3);
	g.add(0,1,2);
	g.add(0,2,1);

	//g.add(1,4,6);
	//g.add(2,4,5);
	
	//g.print();

	g.kruskal();

	
	


	return 0;
}